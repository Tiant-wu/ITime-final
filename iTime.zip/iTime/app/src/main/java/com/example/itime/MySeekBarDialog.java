package com.example.itime;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.PaintDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;



public class MySeekBarDialog extends Dialog {
    Context context;
    private SeekBar colorBar;//用于显示颜色
    public int mColor;
    private ColorPickGradient mColorPickGradient;
    private OnSeekbarChangedListener mListener;//监听SeekBar事件，比如拖动等
    private ClickListenerInterface clickListenerInterface;

    /*获取监听对象*/
    public OnSeekbarChangedListener getmListener() {
        return mListener;
    }
    /*设置监听对象*/
    public void setmListener(OnSeekbarChangedListener mListener) {
        this.mListener = mListener;
    }


    /*自定义构造函数用于初始化*/

     public MySeekBarDialog(Context context) {
        super(context,R.style.DialogTheme);
         this.context = context;

    }
    protected void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        LayoutInflater inflater=LayoutInflater.from(context);
        View view=inflater.inflate(R.layout.mydialog,null);
        setContentView(view);
        colorBar=view.findViewById(R.id.seek_bar);
        mColorPickGradient=new ColorPickGradient();
        initColorBar();

        Button buttonOk=(Button)view.findViewById(R.id.button_ok);
        Button buttonCancel=(Button)view.findViewById(R.id.button_cancel);
        buttonOk.setOnClickListener(new clickListener());
        buttonCancel.setOnClickListener(new clickListener());
        Window dialogWindow = getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        DisplayMetrics d = context.getResources().getDisplayMetrics(); // 获取屏幕宽、高用
        lp.width = (int) (d.widthPixels * 0.6); // 高度设置为屏幕的0.6
        dialogWindow.setAttributes(lp);






    }
    public interface OnSeekbarChangedListener{
        public void onChange(int progress);
    }
    public interface ClickListenerInterface {
        public void doConfirm();

        public void doCancel();
    }
    public void setClickListener(ClickListenerInterface clickListenerInterface){
        this.clickListenerInterface=clickListenerInterface;
    }
    private class clickListener implements View.OnClickListener{

        @Override
        public void onClick(View view) {
            int id= view.getId();
            switch(id){
                case R.id.button_ok:
                    clickListenerInterface.doConfirm();
                    break;
                case R.id.button_cancel:
                    clickListenerInterface.doCancel();
                    break;
            }

        }
    }

    private void initColorBar(){

        ShapeDrawable.ShaderFactory shaderFactory = new ShapeDrawable.ShaderFactory() {
            @Override
            public Shader resize(int width, int height) {
                LinearGradient linearGradient = new LinearGradient(0, 0, width, height,
                        ColorPickGradient.PICKCOLORBAR_COLORS, ColorPickGradient.PICKCOLORBAR_POSITIONS, Shader.TileMode.REPEAT);
                return linearGradient;
            }
        };
        PaintDrawable paint = new PaintDrawable();
        paint.setShape(new RectShape());
        paint.setCornerRadius(10);
        paint.setShaderFactory(shaderFactory);
        colorBar.setProgressDrawable(paint);
        colorBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float radio = (float)progress / colorBar.getMax();
                mColor = mColorPickGradient.getColor(radio);
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }

        });

    }



}
